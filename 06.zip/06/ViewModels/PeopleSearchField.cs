﻿namespace Mach_rocnikova_prace.ViewModels
{
    public enum PeopleSearchField
    {
        Id,
        LastName,
        Insurance,
        Team,
        Role
    }
}